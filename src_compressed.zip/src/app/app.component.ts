import { Component } from '@angular/core';

interface Componente{
  icon: string; 
  name: string; 
  redirecTo:string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
 
  constructor() {}

  componentes : Componente[] = [
    {
      icon: 'information-circle-outline',
      name: 'Información',
      redirecTo: '/content'
    },
    {
      icon: 'bicycle-outline',
      name: 'Ejercicios Prácticos',
      redirecTo: '/ejercicios'
    },
    {
      icon: 'document-text-outline',
      name: 'Contáctanos',
      redirecTo: '/formulario'
    },
    {
      icon: 'newspaper-outline',
      name: 'Recetas',
      redirecTo: '/noticias',
    },
    {
      icon: 'archive-outline',
      name: 'Queremos Conocerte',
      redirecTo: '/datos'
    }
  ];



}
