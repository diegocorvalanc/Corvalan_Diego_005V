export interface RespuestaToHeadLines {
    categories: Categories[];
  }

  export interface Categories {
    idCategory: string;
    strCategory: string;
    strCategoryThumb?: string;
    strCategoryDescription: string;
  }
