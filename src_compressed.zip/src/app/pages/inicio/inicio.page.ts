import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AngularFireAuth, AngularFireAuthModule } from '@angular/fire/compat/auth';
import { AuthService } from 'src/app/services/auth.service';


interface Componente{
  icon: string; 
  name: string; 
  redirecTo:string;
}


@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})

export class InicioPage implements OnInit {

  componentes : Componente[] = [
    {
      icon: 'barbell-outline',
      name: 'Ejercicios Practicos',
      redirecTo: '/action-sheet'
    },
    {
      icon: 'information-circle-outline',
      name: 'Informacion',
      redirecTo: '/alert'
    },
    {
      icon: 'mail-open-outline',
      name: 'Formulario de Contacto',
      redirecTo: '/task'
    },
    {
      icon: 'alarm-outline',
      name: 'Noticias',
      redirecTo: '/noticias',
    },

  ];

  constructor(private menuController: MenuController, private authSvc: AuthService, private router: Router, private afAuth: AngularFireAuth) { }

  onLogout(){
    console.log('Logout!');
    this.afAuth.signOut();
    this.router.navigateByUrl('/login');
  }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }


}
